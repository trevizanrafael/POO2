package Model;

import java.time.LocalDateTime;

public class Admin extends Usuario {
    private LocalDateTime ultimoAcesso;
    private int nivelAcesso;

    public Admin() {}

    public Admin(String CPF, String usuario, String senha, String nome,
                 LocalDateTime ultimoAcesso, int nivelAcesso) {
        super(CPF, usuario, senha, nome);
        this.ultimoAcesso = ultimoAcesso;
        this.nivelAcesso = nivelAcesso;
    }

    public LocalDateTime getUltimoAcesso() { return ultimoAcesso; }
    public void setUltimoAcesso(LocalDateTime ultimoAcesso) { this.ultimoAcesso = ultimoAcesso; }

    public int getNivelAcesso() { return nivelAcesso; }
    public void setNivelAcesso(int nivelAcesso) { this.nivelAcesso = nivelAcesso; }
}
