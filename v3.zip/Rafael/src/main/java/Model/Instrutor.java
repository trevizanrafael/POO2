package Model;




public class Instrutor extends Usuario {
    private String cref;
    private int cargaHoraria;

    public Instrutor() {}

    public Instrutor(String CPF, String usuario, String senha, String nome,
                     String cref, int cargaHoraria) {
        super(CPF, usuario, senha, nome);
        this.cref = cref;
        this.cargaHoraria = cargaHoraria;
    }

    public String getCref() { return cref; }
    public void setCref(String cref) { this.cref = cref; }

    public int getCargaHoraria() { return cargaHoraria; }
    public void setCargaHoraria(int cargaHoraria) { this.cargaHoraria = cargaHoraria; }
}
