/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

/**
 *
 * @author T-GAMER
 */
public class CRUDAlunos {
    public void CriarAluno(){
        //codigo para criar aluno
    }
    
    public void EditarAluno(){
        //codigo para editar aluno
    }
    
    public void ApagarAluno(){
        //codigo para apagar aluno
    }
    
    public void ConsultarAluno(){
        //codigo para consultar aluno
    }
    
}
