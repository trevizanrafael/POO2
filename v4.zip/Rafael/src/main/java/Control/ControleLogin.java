/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

/**
 *
 * @author T-GAMER
 */
public class ControleLogin {
    public void ValidarLogin(){
        //codigo para ver quem entrou e qual perfil etc
    }
    
    public void LogOut(){
        //codigo para logout
    }
}
