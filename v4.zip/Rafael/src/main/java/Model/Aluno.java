package Model;

public class Aluno extends Usuario {
    private Instrutor instrutor;
    private Treino treino;
    private String dataMatricula;

    public Aluno() {}

    public Aluno(String CPF, String usuario, String senha, String nome,
                 Instrutor instrutor, Treino treino, String dataMatricula) {
        super(CPF, usuario, senha, nome);
        this.instrutor = instrutor;
        this.treino = treino;
        this.dataMatricula = dataMatricula;
    }

    public Instrutor getInstrutor() { return instrutor; }
    public void setInstrutor(Instrutor instrutor) { this.instrutor = instrutor; }

    public Treino getTreino() { return treino; }
    public void setTreino(Treino treino) { this.treino = treino; }

    public String getDataMatricula() { return dataMatricula; }
    public void setDataMatricula(String dataMatricula) { this.dataMatricula = dataMatricula; }
}
