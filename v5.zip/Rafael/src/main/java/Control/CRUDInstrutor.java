/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Control;

/**
 *
 * @author T-GAMER
 */
public class CRUDInstrutor {
    public void CriarInstrutor(){
        //codigo para criar instrutor
    }
    
    public void EditarInstrutor(){
        //codigo para editar instrutor
    }
    
    public void ApagarInstrutor(){
        //codigo para apagar instrutor
    }
    
    public void ConsultarInstrutor(){
        //codigo para consultar instrutor
    }
}
