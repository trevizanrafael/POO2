package Model;

public class Exercicio {
    private String nome;
    private float peso;
    private int repeticoes;
    private String observacoes;

    public Exercicio() {}

    public Exercicio(String nome, float peso, int repeticoes, String observacoes) {
        this.nome = nome;
        this.peso = peso;
        this.repeticoes = repeticoes;
        this.observacoes = observacoes;
    }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public float getPeso() { return peso; }
    public void setPeso(float peso) { this.peso = peso; }

    public int getRepeticoes() { return repeticoes; }
    public void setRepeticoes(int repeticoes) { this.repeticoes = repeticoes; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
}
