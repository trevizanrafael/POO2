package Control.BD;

import Model.Exercicio;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.List;

public class ExercicioDAO {

    // === CONFIGURAÇÃO DA CONEXÃO ===
    private static final String URL = "jdbc:postgresql://localhost:5432/gymflow";
    private static final String USER = "postgres";
    private static final String SENHA = "gymflow";
    private static final String DRIVER = "org.postgresql.Driver";

    // === MÉTODO PARA CRIAR A TABELA ===
    public void criarTabela() {
        Connection conn = null;
        Statement st = null;

        String sql = "CREATE TABLE IF NOT EXISTS exercicio (" +
                     "nome VARCHAR(100)," +
                     "peso VARCHAR(20)," +
                     "repeticoes VARCHAR(20))";

        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, SENHA);
            st = conn.createStatement();
            st.executeUpdate(sql);
            System.out.println("Tabela criada com sucesso!");
            st.close();
            conn.close();
        } catch (Exception ex) {
            System.out.println("Erro ao criar tabela: " + ex.getMessage());
        }
    }

    // === MÉTODO PARA SALVAR LISTA DE EXERCÍCIOS ===
    public void salvar(List<Exercicio> lista) {
        if (lista == null || lista.isEmpty()) {
            System.out.println("Lista vazia, nada a salvar.");
            return;
        }

        Connection conn = null;
        Statement st = null;

        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, SENHA);
            st = conn.createStatement();

            for (Exercicio e : lista) {
                if (e.getNome() == null || e.getNome().isBlank()) continue;

                // monta SQL no estilo clássico
                String sql = "INSERT INTO exercicio (nome, peso, repeticoes) VALUES (" +
                        "'" + e.getNome() + "', " +
                        "'" + e.getPeso() + "', " +
                        "'" + e.getRepeticoes() + "')";

                st.executeUpdate(sql);
            }

            System.out.println("Exercícios salvos com sucesso!");
            st.close();
            conn.close();

        } catch (Exception ex) {
            System.out.println("Erro ao salvar exercícios: " + ex.getMessage());
        }
    }
}
