package Control.IA;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;

public class OpenRouterClient {

    private static final String API_URL = "https://openrouter.ai/api/v1/chat/completions";
    private final String apiKey;
    private final HttpClient httpClient;
    private final ObjectMapper objectMapper;

    public OpenRouterClient(String apiKey) {
        this.apiKey = apiKey;
        this.httpClient = HttpClient.newHttpClient();
        this.objectMapper = new ObjectMapper();
    }

    public String chat(String model, List<Map<String, String>> messages) throws IOException, InterruptedException {
        Map<String, Object> requestBody = new HashMap<>();
        requestBody.put("model", model);
        requestBody.put("messages", messages);
        requestBody.put("temperature", 0.7);
        requestBody.put("max_tokens", 200);

        String json = objectMapper.writeValueAsString(requestBody);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(API_URL))
                .header("Authorization", "Bearer " + apiKey)
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() != 200) {
            throw new RuntimeException("Erro da API: " + response.statusCode() + " - " + response.body());
        }

        Map<?, ?> resposta = objectMapper.readValue(response.body(), Map.class);
        List<?> choices = (List<?>) resposta.get("choices");

        if (choices != null && !choices.isEmpty()) {
            Object first = choices.get(0);
            if (first instanceof Map) {
                Map<?, ?> firstMap = (Map<?, ?>) first;
                Object messageObj = firstMap.get("message");
                if (messageObj instanceof Map) {
                    Map<?, ?> msgMap = (Map<?, ?>) messageObj;
                    Object content = msgMap.get("content");
                    if (content != null) {
                        return content.toString();
                    }
                }
            }
        }

        return "Sem resposta da IA.";
    }
}
